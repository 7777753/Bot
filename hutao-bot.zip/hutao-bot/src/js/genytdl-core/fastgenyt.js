'use strict';
module.exports.genyt = require('./lib/server/request.js').genyt;
 
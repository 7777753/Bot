
exports.palavrasANA = [
    {
        resposta: "PASTEL", 
        dica: "salgado", 
        embaralhada: "TELSPA"
    }, 
    {
        resposta: "BALEIA", 
        dica: "vive no oceano", 
        embaralhada: "IELABA"
    }, 
    {
        resposta: "TROVAO", 
        dica: "estar sempre presente nos dias chuvoso", 
        embaralhada: "AOTRVO"
    }, 
    {
        resposta: "INFERNO", 
        dica: "lugar muito quente", 
        embaralhada: "RNOFNIE"
    }, 
    {
        resposta:"CAVALO",
        embaralhada:"LACAVO",
        dica:"animal"
    }, 
    {
        resposta:"COMPUTADOR",
        embaralhada:"PUCOMDORTA",
        dica:"aparelho"
    }, 
    {
        resposta:"TOALHA",
        embaralhada:"OALTHA",
        dica:"tecido"
    },
    {
        resposta:"CAMISA",
        embaralhada:"ACSMIA",
        dica:"vestiario"
    },
    {
        resposta:"CAMA",
        embaralhada:"MACA",
        dica:"conforto"
    },
    {
        resposta:"AGUA",
        embaralhada:"GUAA",
        dica:"liquido"    
    },
    {
        resposta:"JAGUAR",
        embaralhada:"AJUAGR",
        dica:"animal"    
    },
    {
        resposta:"TELEVISAO",
        embaralhada:"TESAOVILE",
        dica:"aparelho"    
    },
    {
        resposta:"PORTA",
        embaralhada:"PORAT",
        dica:"objeto"    
    },        
    {
        resposta:"CELULAR",
        embaralhada:"CULAREL",
        dica:"dipositivo"    
    },        
    {
        resposta:"ONIBUS",
        embaralhada:"NIOBSU",
        dica:"transporte"    
    },            
     {
        resposta:"CRUZEIRO",
        embaralhada:"RUCEROIZ",
        dica:"neymar"    
    },                    
    {
        resposta:"AMBULANCIA",
        embaralhada:"LABUNCIAMA",
        dica:"emergrncia"   
    },            
     {
        resposta:"CHAPEU",
        embaralhada:"PHACEU",
        dica:"estilo"    
    },
{
resposta: 'PARADOXO',
embaralhada: 'XOPARODA',
dica: 'CANAL'
},
{
resposta: 'ESCADA',
embaralhada: 'CAESDA',
dica: 'OBJETO'
},
{
resposta: 'AKAME',
embaralhada: 'MEAKA',
dica: 'PERSONAGEM'
},
{
resposta: 'NAGATORO',
embaralhada: 'GATONARO',
dica: 'PERSONAGEM'
},
{
resposta: 'SASUKE',
embaralhada: 'KESUSA',
dica: 'PERSONAGEM'
},
{
resposta: 'GAY',
embaralhada: 'YAG',
dica: 'VOCÊ'
},
{
resposta: 'CIMENTO',
embaralhada: 'OMCNITE',
dica: 'CONSTRUÇÕES'
},
{
resposta: 'BANANA',
embaralhada: 'NABANA',
dica: 'COMIDA'
},
{
resposta: 'NETFLIX',
embaralhada: 'TFLIXNE',
dica: 'APLICATIVO'
},
{
resposta: 'YOUTUBE',
embaralhada: 'TUBEYOU',
dica: 'APLICATIVO'
},
{
resposta: 'PORTUGAL',
embaralhada: 'TUGALPOR',
dica: 'PAÍS'
},
{
resposta: 'PISTOLA',
embaralhada: 'TOPISLA',
dica: 'OBJETO'
},
		
{
resposta: 'CAMARÃO',
embaralhada: 'MARÃOCA',
dica: 'COMIDA'
},
{
resposta: 'HIDRANTE',
embaralhada: 'TEHDIRAN',
dica: 'OBJETO'
},
{
resposta: 'FOGUETE',
embaralhada: 'TEFOGUE',
dica: 'OBJETO'
},
{
resposta: 'SKATE',
embaralhada: 'TEASK',
dica: 'OBJETO'
},
{
resposta: 'MACACO',
embaralhada: 'CACOMA',
dica: 'ANIMAL'
},
{
resposta: 'LASANHA',
embaralhada: 'NHASALA',
dica: 'COMIDA'
},
{
resposta: 'PASTEL',
embaralhada: 'PATELS',
dica: 'COMIDA'
},
{
resposta: 'COXINHA',
embaralhada: 'XICONHA',
dica: 'COMIDA'
},
{
resposta: 'BICICLETA',
embaralhada: 'CIBITACLE',
dica: 'OBJETO'
},
{
resposta: 'SASUKE',
embaralhada: 'ESASUK',
dica: 'PERSONAGEM'
},
{
resposta: 'CAVALO',
embaralhada: 'LACAVO',
dica: 'ANIMAL'
},
{
resposta: 'LEVI',
embaralhada: 'EVIL',
dica: 'PERSONAGEM'
},
{
resposta: 'KAMAITACHI',
embaralhada: 'TAICAMAKHI',
dica: 'CANTOR'
},
{
resposta: 'LUBA',
embaralhada: 'UBAL',
dica: 'YOUTUBER'
},
{
resposta: 'GRÊMIO',
embaralhada: 'OMÊGRI',
dica: 'TIME'
},
{
resposta: 'SATURNO',
embaralhada: 'UTARSON',
dica: 'PLANETA'
},
{
resposta: 'MIKASA',
embaralhada: 'KAMISA',
dica: 'PERSONAGEM'
},
{
resposta: 'LEÃO',
embaralhada: 'OLEÃ',
dica: 'ANIMAL'
},
{
resposta: 'SAKURA',
embaralhada: 'SUKARA',
dica: 'PERSONAGEM'
},
{
resposta: 'HADES',
embaralhada: 'SEDAH',
dica: 'MITOLOGIA'
},
{
resposta: 'CORRIDA',
embaralhada: 'ARROCID',
dica: 'ESPORTE'
},
{
resposta: 'ODIN',
embaralhada: 'NODI',
dica: 'MITOLOGIA'
},
{
resposta: 'BICICLETA',
embaralhada: 'CIBITACLE',
dica: 'OBJETO'
},
{
resposta: 'BICICLETA',
embaralhada: 'CIBITACLE',
dica: 'OBJETO'
},
{
resposta: 'GUATEMALA',
embaralhada: 'LATEMAGUA',
dica: 'PAÍS'
},
{
resposta: 'CEREJA',
embaralhada: 'ECREJA',
dica: 'FRUTA'
},
{
resposta: 'VENEZUELA',
embaralhada: 'ZUNEEVELA',
dica: 'PAÍS'
},
{
resposta: 'HISTÓRIA',
embaralhada: 'TÓRISIAH',
dica: 'MATÉRIA'
},
{
resposta: 'INSTAGRAM',
embaralhada: 'TAGRAMINS',
dica: 'APLICATIVO'
},
{
resposta: 'WHATSAPP',
embaralhada: 'TSWHAAPP',
dica: 'APLICATIVO'
},
{
resposta: 'HIDRANTE',
embaralhada: 'TEHDIRAN',
dica: 'OBJETO'
},
{
resposta: 'CELULAR',
embaralhada: 'CELARLU',
dica: 'OBJETO'
},
{
resposta: 'NOTEBOOK',
embaralhada: 'TENOBOOK',
dica: 'OBJETO'
},
{
resposta: 'COMPUTADOR',
embaralhada: 'PUCOMDORTA',
dica: 'OBJETO'
},
{
resposta: 'LANTERNA',
embaralhada: 'TERLANNA',
dica: 'OBJETO'
},
{
resposta: 'CACHORRO',
embaralhada: 'HRROAOCC',
dica: 'ANIMAL'
},
{
resposta: 'DESENTUPIDOR',
embaralhada: 'SENDETUDORPI',
dica: 'OBJETO'
},
{
resposta: 'TOMATE',
embaralhada: 'ATEMOT',
dica: 'ALIMENTO'
},
{
resposta: 'SAXOFONE',
embaralhada: 'ASXOEOFN',
dica: 'INSTRUMENTO MUSICAL'
},
{
resposta: 'CAZAQUISTÃO',
embaralhada: 'ZAACQIUSÃOT',
dica: 'PAÍS'
},
{
resposta: 'CROÁCIA',
embaralhada: 'CRCÁOAI',
dica: 'PAÍS'
},
{
resposta: 'HUNGRIA',
embaralhada: 'UHGINRA',
dica: 'PAÍS'
},
{
resposta: 'MEGAFONE',
embaralhada: 'MOEFGNEA',
dica: 'OBJETO'
},
{
resposta: 'CINTURA',
embaralhada: 'RCIANUT',
dica: 'CORPO HUMANO'
},
{
resposta: 'ABDÔMEN',
embaralhada: 'MBÔDENA',
dica: 'CORPO HUMANO'
},
{
resposta: 'VAGNER',
embaralhada: 'GNEVAR',
dica: 'NOME'
},
{
resposta: 'ALEATORY',
embaralhada: 'YRTALOEA',
dica: 'NOME'
},
{  
resposta: 'CAFIN',
embaralhada: 'NFCIA',
dica: 'TIPO DE GAY'
},
{    
resposta: 'KONEKO',
embaralhada: 'NOEKKO',
dica: 'NOME'
},
{
resposta: 'RAPOSA',
embaralhada: 'APRSAO',
dica: 'ANIMAL'
},
{
resposta: 'INFERNO',
embaralhada: 'RNOFNIE',
dica: 'LUGAR'
},
{   
resposta: 'RINOCERONTE',
embaralhada: 'NTERRECNIOO',
dica: 'ANIMAL'
},
{ 
resposta: 'PASTOR',
embaralhada: 'STRPAO',
dica: 'BATIZADO'
},
{
resposta: 'BONITO',
embaralhada: 'NTBIOO',
dica: 'COMENTÁRIO'
},
{       
resposta: 'TANGERINA',
embaralhada: 'RITAANGNE',
dica: 'ALIMENTO'
},          
{       
resposta: 'INSTAGRAM',
embaralhada: 'MASTGRMIAN',
dica: 'REDE SOCIAL'
},
{       
resposta: 'CAPIVARA',
embaralhada: 'RAPIVACA',
dica: 'ANIMAL'
}
];

exports.quizanimais = [
{
original: 'PORQUINHO DA ÍNDIA',
foto: 'https://telegra.ph/file/617e247a4fbb63d299198.jpg'
},
{
original: 'HAMSTER',
foto: 'https://telegra.ph/file/a478979f342ac1746a645.jpg'
},
{
original: 'ROTTWEILER',
foto: 'https://telegra.ph/file/a10ad7df6ab6a2312a1f9.jpg'
},
{
original: 'FLOPPA',
foto: 'https://telegra.ph/file/7633abcd83b8a587f418d.jpg'
},
{
original: 'GUAXINIM',
foto: 'https://telegra.ph/file/3800c7048d04a1c3dbc4e.jpg'
},
{
original: 'ZEBRA',
foto: 'https://telegra.ph/file/a08e224344e34aa916972.jpg'
},
{
original: 'CARNEIRO',
foto: 'https://telegra.ph/file/096342c8c7815ba9d83be.jpg'
},
{
original: 'BODE',
foto: 'https://telegra.ph/file/ff574a82178089f453444.jpg'
},
{
original: 'MAMUTE',
foto: 'https://telegra.ph/file/00e445dde6c036a0c0df5.jpg'
},
{
original: 'ALPACA',
foto: 'https://telegra.ph/file/a201b23b179392f1cdd7f.jpg'
},
{
original: 'PORCO ESPINHO',
foto: 'https://telegra.ph/file/7b180efc77c8ab6e9a24a.jpg'
},
{
original: 'QUOKKA',
foto: 'https://telegra.ph/file/3042e66a22c6d0fb6e0cd.jpg'
},
{
original: 'PANDA VERMELHO',
foto: 'https://telegra.ph/file/a6517debde47b846073cc.jpg'
},
{
original: 'PEIXE GOTA',
foto: 'https://telegra.ph/file/e8892204b373c147bf489.jpg'
},
{
original: 'PEIXE MANDARIM',
foto: 'https://telegra.ph/file/e8892204b373c147bf489.jpg'
},
{
original: 'DRAGÃO DE KOMODO',
foto: 'https://telegra.ph/file/d4c36b449f4c781533f3c.jpg'
},
{
original: 'LEOPARDO',
foto: 'https://telegra.ph/file/0016017b9d28a3b6d027a.jpg'
},
{
original: 'FURÃO',
foto: 'https://telegra.ph/file/e352b4831db11c20a3c62.jpg'
},
{
original: 'LEOPARDO',
foto: 'https://telegra.ph/file/71f5f532ced0fddc08f5b.jpg'
},
{
original: 'LEBRE',
foto: 'https://telegra.ph/file/89f9a46ce660261279477.jpg'
},
{
original: 'MARRECO',
foto: 'https://telegra.ph/file/aa41bde6c4c350ec9d0d4.jpg'
},
{
original: 'GANSO',
foto: 'https://telegra.ph/file/9ab69884414feefc9c109.jpg'
},
{
original: 'CAVALO MARINHO',
foto: 'https://telegra.ph/file/e4cee57d5b731dfffa5d8.jpg'
},
{
original: 'CROCODILO',
foto: 'https://telegra.ph/file/b4483f9a7077fd29a137f.jpg'
},
{
original: 'ORNITORRINCO',
foto: 'https://telegra.ph/file/8ffdd62da1834433112be.jpg'
},
{
original: 'HUSKY SIBERIANO',
foto: 'https://telegra.ph/file/07b98023259637951ba8f.jpg'
},
{
original: 'CAPIVARA',
foto: 'https://telegra.ph/file/54f20cbd80737fe45a284.jpg'
}
];

exports.enigmaArchive = [
{
numero: "ENIGMA 1",
respostaEne: "O FÓSFORO",
charada: "Imagine que você está em uma sala escura ao lado de Sherlock. Nela há um fósforo, uma lâmpada de querosene, uma vela e uma lareira. O que você acenderia primeiro?"
},
{
numero: "ENIGMA 2",
respostaEne: "SEGREDO",
charada: "O detetive Sherlock encontrou um bilhete que faz parte de uma pista de um mistério que precisa ser solucionado. “Se você me tem, quer me compartilhar; se você não me compartilha, você me manteve. O que eu sou?”"
},
{
numero: "ENIGMA 3",
respostaEne: "NENHUM",
charada: "Watson e Sherlock adoram brincar com enigmas para treinar o método científico. Ajude-os a encontrar a resposta desse enigma: um macaco, um esquilo e um pássaro estão correndo para o topo de um coqueiro. Quem pegará a banana primeiro, o macaco, o esquilo ou o pássaro?"
},
{
numero: "ENIGMA 4",
respostaEne: "ECO",
charada: "Eu falo, mas não tenho boca. Eu ouço, mas não tenho ouvidos. Não tenho corpo, mas vivo com o vento. Quem sou eu?"
},
{
numero: "ENIGMA 5",
respostaEne: "IDADE",
charada: "Eu sou algo que as pessoas amam ou odeiam. Eu mudo tanto a aparência das pessoas quanto seus pensamentos. Se uma pessoa cuida de si mesma, eu subo ainda mais. Eu engano algumas pessoas. E para outras, sou um verdadeiro mistério. Algumas pessoas bem que tentam me esconder, mas uma hora, inevitavelmente, eu apareço. Não importa o que as pessoas tentem, eu jamais cairei. Quem sou eu?"
},
{
numero: "ENIGMA 6",
respostaEne: "SOMBRA",
charada: "Tenho apenas uma cor, mas posso ter vários tamanhos. Estou presente quando faz sol. Na chuva, jamais! Passo todo o tempo no chão, mas nunca fico sujo. Não faço mal algum e não posso sentir dor. Quem sou eu?"
},
{
numero: "ENIGMA 7",
respostaEne: "12 ANOS",
charada: "Perguntaram para Maria quantos anos ela tem. Maria respondeu que em dois anos terá o dobro da idade que ela tinha há cinco anos. Quantos anos Maria tem?"
},
{
numero: "ENIGMA 8",
respostaEne: "ESCURIDÃO",
charada: "Quanto mais houver de mim, menos você verá. Quem sou eu?"
},
{
numero: "ENIGMA 9",
respostaEne: "ESPONJA",
charada: "Sou cheio de buracos, mas ainda assim consigo reter muita água. Quem sou eu?"
},
{
numero: "ENIGMA 9",
respostaEne: "COTOVELO DIREITO",
charada: "O que você pode segurar com a sua mão esquerda, mas jamais com a direita?"
},
{
numero: "ENIGMA 10",
respostaEne: "ÂNCORA",
charada: "Quando precisa de mim, você me atira para longe, até um lugar onde ninguém pode me ver. Mas quando já não precisa mais, você me traz de volta. Quem sou eu?"
},
{
numero: "ENIGMA 11",
respostaEne: "AS PALAVRAS",
charada: "Nós podemos machucar sem fazer um único movimento. Podemos envenenar sem tocar. Carregamos a verdade e a mentira. E não devemos ser julgadas pelo nosso tamanho Quem somos nós?"
},
{
numero: "ENIGMA 12",
respostaEne: "UMA TESOURA",
charada: "Ponha os dedos nos meus olhos que eu abrirei as minhas potentes mandíbulas. E vou devorar tudo o que vier pela frente: roupas, penas, papéis. Quem sou eu?"
},
{
numero: "ENIGMA 13",
respostaEne: "ALFABETO",
charada: "Eu posso guardar tudo dentro de mim. Tudo o que você pode imaginar: o vento, as florestas, o mundo, o universo e até Deus. Tudo o que vier à sua cabeça você pode encontrar dentro de mim. Quem sou eu?"
},
{
numero: "ENIGMA 14",
respostaEne: "DINHEIRO FALSO",
charada: "Quem me faz não diz que faz. Quem me tem não sabe que tem. E quem sabe não me quer ter de jeito nenhum. Quem sou eu?"
},
{
numero: "ENIGMA 15",
respostaEne: "ESCURIDÃO",
charada: "Quanto mais houver de mim, menos você verá. Quem sou eu?"
},
{
numero: "ENIGMA 16",
respostaEne: "A CONFIANÇA",
charada: "O que pode ser quebrada, mas nunca segurada?"
},
{
numero: "ENIGMA 17",
respostaEne: "OPÇÃO",
charada: "Se há três, você tem três. Se há duas, você tem duas. Mas se há uma, você não tem nenhuma. O que é?"
},
{
numero: "ENIGMA 18",
respostaEne: "O PADRE",
charada: "Já casei muitas vezes, mas estou sempre solteiro. Quem sou eu?"
},
{
numero: "ENIGMA 19",
respostaEne: "JOÃO",
charada: "A mãe do João teve cinco filhos. O primeiro se chamava Dadá, o segundo Dedé, o terceiro, Didi, e o quarto, Dodó. Como se chamava o quinto filho?"
},
{
numero: "ENIGMA 20",
respostaEne: "O CAIXÃO",
charada: "O que é, o que é: quem faz não quer, quem compra não usa e quem usa não fica sabendo?"
}
];

exports.garticArchives = [
{
pergunta: 'Aplicativo',
imagem: 'https://telegra.ph/file/dfa10e1cd64bfd575b26a.jpg',
letra_inicial: 'N',
contem_traços: '❌️️',
resposta: 'NETFLIX'
},
{
pergunta: 'Aplicativo',
imagem: 'https://telegra.ph/file/070fbfa1cccd65681f3fa.jpg',
letra_inicial: 'F',
contem_traços: '❌️️',
resposta: 'FACEBOOK'
},
{
pergunta: 'Desenho',
imagem: 'https://telegra.ph/file/1e344b9cde13d5a6c6095.jpg',
letra_inicial: 'TO',
contem_traços: '❌️️',
resposta: 'TOM E JERRY'
},
{
pergunta: 'Objeto',
imagem: 'https://telegra.ph/file/af0e70ea5a92cbfc71f43.jpg',
letra_inicial: 'GU',
contem_traços: '✅️️️',
resposta: 'GUARDA-CHUVA'
},
{
pergunta: 'Profissão',
imagem: 'https://telegra.ph/file/cbea80472e3d2624676a6.jpg',
letra_inicial: 'J',
contem_traços: '❌️️️️',
resposta: 'JUIZ'
},
{
pergunta: 'Aplicativo',
imagem: 'https://telegra.ph/file/b5a9a0de5e222b5084a8a.jpg',
letra_inicial: 'SN',
contem_traços: '❌️️',
resposta: 'SNAPCHAT'
},
{
pergunta: 'Países',
imagem: 'https://telegra.ph/file/5721a0cde0166bee675e5.jpg',
letra_inicial: 'E',
contem_traços: '❌️️',
resposta: 'ESPANHA'
},
{
pergunta: 'Objeto',
imagem: 'https://telegra.ph/file/bdb05184d2d6f5a7d1ecf.jpg',
letra_inicial: 'D',
contem_traços: '❌️️',
resposta: 'DARDOS'
},
{
pergunta: 'Objeto',
imagem: 'https://telegra.ph/file/317913121ec9ca6aae71b.jpg',
letra_inicial: 'D',
contem_traços: '❌️️',
resposta: 'DOMINÓ'
},
{
pergunta: 'Objeto',
imagem: 'https://telegra.ph/file/63eca8c97ed165bfecfe5.jpg',
letra_inicial: 'C',
contem_traços: '❌️️',
resposta: 'CANADÁ'
},
{
pergunta: 'Jogos',
imagem: 'https://telegra.ph/file/68ea5f4b182ae4c501a32.jpg',
letra_inicial: 'X',
contem_traços: '❌️️',
resposta: 'XADREZ'
},
{
pergunta: 'Filme',
imagem: 'https://telegra.ph/file/a29ac8b0638d9e23bdab0.jpg',
letra_inicial: 'A',
contem_traços: '❌️️',
resposta: 'A ORIGEM'
},
{
pergunta: 'Filme',
imagem: 'https://telegra.ph/file/b3e2aaca939ed0cdf7a73.jpg',
letra_inicial: 'OS',
contem_traços: '❌️️',
resposta: 'OS SETE SAMURAIS'
},
{
pergunta: 'Filme',
imagem: 'https://telegra.ph/file/ab11fa68eda5abe19562b.jpg',
letra_inicial: 'SE',
contem_traços: '❌️️',
resposta: 'SENHOR DOS ANÉIS'
},
{
pergunta: 'Filme',
imagem: 'https://telegra.ph/file/de030e592fecdc2cf0d20.jpg',
letra_inicial: 'JU',
contem_traços: '❌️️',
resposta: 'JUMANJI'
},
{
pergunta: 'Filme',
imagem: 'https://telegra.ph/file/aafcb73c2dd10aef1bd47.jpg',
letra_inicial: 'S',
contem_traços: '❌️️',
resposta: 'SONIC'
},
{
pergunta: 'Série',
imagem: 'https://telegra.ph/file/e0c905d9630bf9d36df77.jpg',
letra_inicial: 'TH',
contem_traços: '❌️️',
resposta: 'THE WALKING DEAD'
},
{
pergunta: 'Desenho',
imagem: 'https://telegra.ph/file/d30cac0c8bb2159d38192.jpg',
letra_inicial: 'SI',
contem_traços: '❌️️',
resposta: 'SIMPSONS'
},
{
pergunta: 'Série',
imagem: 'https://telegra.ph/file/c2a993a353fcca61242e4.jpg',
letra_inicial: 'ST',
contem_traços: '❌️️',
resposta: 'STRANGER THINGS'
},
{
pergunta: 'Série',
imagem: 'https://telegra.ph/file/fac611a1d9e2c2fc14957.jpg',
letra_inicial: 'PE',
contem_traços: '❌️️',
resposta: 'PEAKY BLINDERS'
},
{
pergunta: 'Série - Documentário',
imagem: 'https://telegra.ph/file/ecd17a4b75e4541bd20b8.jpg',
letra_inicial: 'CH',
contem_traços: '❌️️',
resposta: 'CHERNOBYL'
},
{
pergunta: 'Países',
imagem: 'https://telegra.ph/file/05164ea8e02880f74010b.jpg',
letra_inicial: 'C',
contem_traços: '❌️️',
resposta: 'CHINA'
},
{
pergunta: 'Países',
imagem: 'https://telegra.ph/file/24161e5698f3874c285eb.jpg',
letra_inicial: 'S',
contem_traços: '❌️️',
resposta: 'SUÍÇA'
},
{
pergunta: 'Países',
imagem: 'https://telegra.ph/file/0207859d0fcb2c7624f1b.jpg',
letra_inicial: 'S',
contem_traços: '❌️️',
resposta: 'COREIA DO SUL'
},
{
pergunta: 'Países',
imagem: 'https://telegra.ph/file/4890a8e71a7cc8d3862d0.jpg',
letra_inicial: 'AR',
contem_traços: '❌️️',
resposta: 'ARGENTINA'
},
{
pergunta: 'Países',
imagem: 'https://telegra.ph/file/dfb6e013f52a018032625.jpg',
letra_inicial: 'P',
contem_traços: '❌️️',
resposta: 'PORTUGAL'
},
{
pergunta: 'Países',
imagem: 'https://telegra.ph/file/8d238d4ffa865dd7009a7.jpg',
letra_inicial: 'F',
contem_traços: '❌️️',
resposta: 'FRANÇA'
}
];

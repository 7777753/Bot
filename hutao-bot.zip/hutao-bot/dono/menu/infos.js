module.exports = {

infodono(NickDono, NomeDoBot, NumeroDoDono, dono1, dono2, dono3, dono4, dono5, dono6 ) {
return `
╭━━━✰°❀•°✮°•❀°✾✰━━━╮
┝⋆⃟ۣۜ᭪➣ 𖡦 𝐈𝐍𝐅𝐎 𝐃𝐎𝐍𝐎 【👑】
╰━━━✰°❀•°✮°•❀°✾✰━━━╯
┃╭━━─ ≪ •❈• ≫ ─━━╮
┃╎ ✫✫✫✫✫
┃╎ 𝐋𝐢𝐝𝐞𝐫𝐞𝐬 𝐝𝐚 ${NomeDoBot}
┃╎
┃╎᭪➣ 𝐃𝐨𝐧𝐨 𝐨𝐟𝐢𝐜𝐢𝐚𝐥: -〘 ${NickDono} 〙-
┃╎↳ 𝐍𝐮𝐦𝐞𝐫𝐨:〘 ${NumeroDoDono} 〙
┃╎
┃╎᭪➣  𝐿𝑖𝑑𝑒𝑟1: -〘 ${dono1} 〙-
┃╎᭪➣  𝐿𝑖𝑑𝑒𝑟2: -〘 ${dono2} 〙-
┃╎᭪➣  𝐿𝑖𝑑𝑒𝑟3: -〘 ${dono3} 〙-
┃╎᭪➣  𝐿𝑖𝑑𝑒𝑟4: -〘 ${dono4} 〙-
┃╎᭪➣  𝐿𝑖𝑑𝑒𝑟5: -〘 ${dono5} 〙-
┃╎᭪➣  𝐿𝑖𝑑𝑒𝑟6: -〘 ${dono6} 〙-
┃╎
┃╎ ✫✫✫✫✫
┃╰━━─ ≪ •❈• ≫ ─━━╯
╰━━━✰°❀•°✮°•❀°✾✰━━━╯

✰✰✰✰✰`;
},
infobv(prefixo, NomeDoBot) {
return `

╭︎⊰๑ᨐ✶乡»̶❁︎«̶乡✶ᨐ๑⊱╮︎ 
╎💫 ∆𝐁𝐄𝐌-𝐕𝐈𝐍𝐃𝐎∆ 💫
╰︎⊰๑ᨐ✶乡»̶❁︎«̶乡✶ᨐ๑⊱╯︎
╎ 『 O bem-vindo, é uma mensagem que o bot envia toda vez que alguém entrar ou for adicionado ao seu grupo. Abaixo irei mostrar o passo a passo de como configura-lo. 』
┗│
╎
╭︎⊰๑ᨐ✶乡»̶❁︎«̶乡✶ᨐ๑⊱╮︎ 
╎🪄∆𝐔𝐒𝐎∆🪄
╰︎⊰๑ᨐ✶乡»̶❁︎«̶乡✶ᨐ๑⊱╯︎
╎ 『 Primeiro você deve ativar o bem-vindo caso não esteja ativo. Use: 
╎• *${prefixo}bemvindo* ( _Com imagem e legenda_ )
╎• *${prefixo}bemvindo2* ( _Somente a legenda_ ) 』
┗│
╎
╭︎⊰๑ᨐ✶乡»̶❁︎«̶乡✶ᨐ๑⊱╮︎ 
╎💥∆𝐋𝐄𝐆𝐄𝐍𝐃𝐀∆💥
╰︎⊰๑ᨐ✶乡»̶❁︎«̶乡✶ᨐ๑⊱╯︎
╎『Para criar a legenda você deve digitar este
╎comando ↴
╎
╎『 *${prefixo}legendabv* ou *${prefixo}legendabv2*, e após sua legenda.
╎
╎  • Configurações básicas para a legenda.
╎
╎✤࣭ٜ࣭ٜ࣭ٜ࣭ٜ⃕◗⃞ ⃝✿ | #nomedogp# É o nome do grupo;
╎
╎✤࣭ٜ࣭ٜ࣭ٜ࣭ٜ⃕◗⃞ ⃝✿ | #nmrbot# Mostra o número do bot;
╎
╎✤࣭ٜ࣭ٜ࣭ٜ࣭ٜ⃕◗⃞ ⃝✿ | #nmr# Menciona o "@" do participante;
╎
╎✤࣭ٜ࣭ٜ࣭ٜ࣭ٜ⃕◗⃞ ⃝✿ | #prefixo# Mostra o prefixo do bot;
╎
╎✤࣭ٜ࣭ٜ࣭ٜ࣭ٜ⃕◗⃞ ⃝✿ | #desc# Exibe toda a descrição do grupo;
╎
╎✤࣭ٜ࣭ٜ࣭ٜ࣭ٜ⃕◗⃞ ⃝✿ | #time# Informa a hora atual ( Horário de Brasília ).
╎
╎ 『E também tem esse comando: ↴
╎
╎『 *${prefixo}legendasaiu* ou *${prefixo}legendasaiu2*, com o mesmo tipo de legenda acima, so que para quando o usuário sair ou ser removido do grupo. 』
┗│
  
╭︎⊰๑ᨐ✶乡»̶❁︎«̶乡✶ᨐ๑⊱╮︎ 
╎✨∆𝐂𝐑𝐄𝐃𝐈𝐓𝐎𝐒∆✨
╰︎⊰๑ᨐ✶乡»̶❁︎«̶乡✶ᨐ๑⊱╯︎  
╎
╎✰ۣۜۜ͜͡By: 𝐿𝑚 ✰
╎
╎✰ۣۜۜ͜͡Bot: ${NomeDoBot}
╎
┗│
╰︎⊰๑ᨐ✶乡»̶❁︎«̶乡✶ᨐ๑⊱╯︎

✰✰✰✰✰`;
},
infobot(sender, prefixo, NomeDoBot, NickDono, NumeroDoDono) {
return `
┏═•✭･ﾟ✧*･ﾟ| ⊱✿⊰ |*✭˚･ﾟ✧･ﾟ•═┓
┣⋆⃟ۣۜ᭪➣ 𖡦 𝐈𝐍𝐅𝐎 𝐃𝐎 𝐁𝐎𝐓 【🍸】
┗═•✭･ﾟ✧*･ﾟ| ⊱✿⊰ |*✭˚･ﾟ✧･ﾟ•═┛
╎
‎┏═•✭･ﾟ✧*･ﾟ| ⊱✿⊰ |*✭˚･ﾟ✧･ﾟ•═┓
┃╭━━─ ≪ •❈• ≫ ─━━╮
┃╎ ✫✫✫✫✫
┃╎ Hii!! @${sender.split('@')[0]} ฅ^•ﻌ•^ฅ
┃╎᭪➣ Prefixo: 〘 ${prefixo} 〙
┃╎᭪➣ Nome do bot: ${NomeDoBot}
┃╎᭪➣ Versão do bot: 8.0.0 💎
┃╎᭪➣ Baileys version: 6.7.9 
┃╎᭪➣ Tema: Hutao / Genshin Impact〘 Game 〙
┃╎᭪➣ Dono: ${NickDono}
┃╎᭪➣ Numero do dono: ${NumeroDoDono}
┃╎᭪➣ Criador: 𝐿𝑚 🥀 | 559284828701
┃╎ ✫✫✫✫✫
┃╰━━─ ≪ •❈• ≫ ─━━╯
┗═•✭･ﾟ✧*･ﾟ| ⊱✿⊰ |*✭˚･ﾟ✧･ﾟ•═┛‎

✰✰✰✰✰`;
},
configurar_bot(prefixo) {
return `‎*⏤͟͟͞͞Aqui estão os principais comandos para configurar seu bot corretamente:* 🙇‍♀️⬇️‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎


『1』 ↴
-
  ░⃟⃛ ➮ *${prefixo}Prefixo* ↴

  ➥ _Este comando serve para mudar o prefixo do bot_

   • Exemplo:
   ↳ [  *${prefixo}Prefixo* !  ]
${"─".repeat(20)}


『2』 ↴
-
  ░⃟⃛ ➮ *${prefixo}NickBot* ↴

  ➥ _Use-o para nomea-lo seu bot com o nome que deseja_ 

   • Exemplo:
   ↳ [  *${prefixo}NickBot* _Novo Nick_  ]
${"─".repeat(20)}


『3』 ↴
-
  ░⃟⃛ ➮ *${prefixo}NickDono* ↴

  ➥ _Defina seu nome como dono do bot_

   • Exemplo:
   ↳ [  *${prefixo}NickDono* _Novo Nome_  ]
${"─".repeat(20)}


『4』 ↴
-
  ░⃟⃛ ➮ *${prefixo}Numero_Dono* ↴

  ➥ _Este comando é essencial para que comandos de dono seja executado. Obs: ( O número deve ser sem +, (), e espaços ) 

   • Exemplo:
   ↳ [  *${prefixo}Numero_Dono* 551122334455  ]
${"─".repeat(20)}


『5』 ↴
-
  ░⃟⃛ ➮ *${prefixo}NomeBot* ↴

  ➥ _Diferente do comando *${prefixo}NickBot*, este comando é usado para mudar o nome no perfil do Whatsapp_

   • Exemplo:
   ↳ [  *${prefixo}NomeBot* _Novo Nome_  ]
${"─".repeat(20)}


• ❗ Para saber mais sobre os comandos de dono use: *${prefixo}MenuDono* ❗
`;
},
infoclosegp(sender, prefixo) {
return `
Hii @${sender.split("@")[0]}!!

Para saber como usar o sistema de abertura e fechamento automático de grupo, vamos analisar os comandos: ↴

➥ *${prefixo}Opengp* ↴

➣ Use da seguinto forma... Defina a hora para o grupo abrir, por exemplo ( 06:00 ), assim ele será aberto todas as 06:00 da manhã
• Além de definir a hora, você pode "*Ativar*" ou "*Desativar*" A abertura do grupo sem prescisar deletar nada ( *${prefixo}Opengp* ativar / desativar )

➥ *${prefixo}Closegp* ↴

➣ Também é da mesma forma quanto o comando acima, definindo a hora em que o grupo irá fechar ( por exemplo: 22:00 )
• Você também pode "*Ativar*" ou "*Desativar*" o fechamento automático do grupo ( *${prefixo}Closegp* ativar / desativar )

➥ *${prefixo}Rm_closegp* ↴

➣ Este é para caso você queira deletar por completa os registro de abertura e fechamento automático do grupo

Espero ter ajudado!! 🙇‍♀️`;
},
 infocontador(prefixo, sender, NomeDoBot) {
return`

• Se você está lendo isso é porque está curioso(a) sobre o contador de mensagem de grupos. 

contém alguns comandos

-
(1) ${prefixo}rankativos

(Descrição: Ele mostra os tops 5 com mais mensagem e comandos executados do bot, no grupo, mas essas mensagem, apenas serão contadas se o bot estiver ativo no termux, ele vai armazenar os dados de cada um que enviar mensagem.) 
 -      -      -       -       -       - 
 
 
 
-               
(2) ${prefixo}atividades

(Descrição:  Este comando, ele mostra as atividades de todos os membros do grupo, mas devo lembrar novamente que só no termux que armazena os dados.)
-    -   -    -    -    -    -   -    -   -



-
(3) ${prefixo}check

(Descrição: Esse comando, você deve marcar a pessoa, Exemplo: ${prefixo}checkativo @marca-a-pessoa-do-gp, e assim como esse, é semelhante o aos outros 2.)
-   -   -   -   -   -   -   -   -   -   - 



(4) ${prefixo}banghost

(Descrição: Preste muita atenção, este comando, você deve digitar ele, mais a quantidade de mensagem que é pra banir as pessoas que tiver abaixo daquela quantidade.

ele vai banir todos aqueles que tiver com 0 mensagem, mas não digite este comando fora do termux (EXEMPLO: HOSPEDADO EM SITES, NÃO NO TERMUX, COMO FOSSE COMANDO, O COMANDO É PRA SER EXECUTADO NO WHATSAPP) , pois ele vai remover todos sem parar, que tiver 0 mensagem, já no termux, ele bane uma pessoa por comando, leia com atenção isso, pois não irei ser responsável por remover todos do seu grupo, por seus erros, recomendo deixar o bot on por 1 semana no grupo, pra usar esse comando, e banir aqueles que nunca enviou mensagem no grupo.)

by: ${NomeDoBot}
 `;
},
info_listanegra(prefixo, sender, NomeDoBot) {
return `
Este comando é usado para registrar números que serão banidos caso entrem no grupo.

_Há um comando para administração e outro para lideres do bot_

    *Uso dos comandos para a administração*
    
  • *${prefixo}ListaNegra*
  ( Você pode mencionar a mensagem da pessoa ou digitar o número dela por exemplo ${prefixo}listanegra ${sender.split('@')[0]} )
  
  • *${prefixo}TirarDaLista*
  ( Mesmo processo mencionado acima... Mencione a mensagem ou digite o número sem espaços )
  
  • *${prefixo}ListBan* _lista de números_
  ( Este é onde está todos os números registrados na lista negra, é util para você  que deseja remover um número da lista usando ${prefixo}tirardalista )
  
   
  *Comandos para líderes e dono*
  
  • _LISTA NEGRA GLOBAL_
   
  ° Para líderes do bot há informações extras sobre esta função, use: *${prefixo}infocmd listg_global*
  
  • É basicamente o mesmo processo da listanegra acima, porém esta remove usuarios de todos os grupos que o *bot tem adm*
  
  • *${prefixo}ListaNegraG*
  ( Mencione a mensagem, "@" ou digite apenas o número sem espaços )
  
  • *${prefixo}TirarDaListaG*
  ( Para remover um número da listanegra global, use *${prefixo}ListBanG* )
  
Bot: ${NomeDoBot}
`;
},
info_adverter(prefixo, sender, NomeDoBot) {
return `

*_INSTRUÇÕES DE USO:_*

  • *${prefixo}adverter*
  ( Use-o para adverter usuários mencionando a mensagem ou o arroba "@". Lembrando que quando o usuario for advertido com 3/3 advertencias, ele será removido imediatamente quando _possível_. Caso queira adicionar advertencias extras, use o exemplo: *${prefixo}adverter  @${sender.split('@')[0]}/2* ou  *${prefixo}adverter /2* )
  
  OBS: _qualquer usuario que não seje lider ou dono, poderá levar advertencias do bot_
  
  • *${prefixo}ver_adv*
  ( Usado para ver quantas advertencias de tal usuario. Mencione a mensagem ou o arroba "@" de alguém que tenha sido advertido )
  
  • *${prefixo}rm_adv*
  ( Remova advertencias de um usuario, por exemplo você pode usar o comando 1 vez para subtrair apenas 1 advertencia, ou você pode usar o mesmo processo acima, exemplo: *${prefixo}rm_adv @${sender.split('@')[0]}/2* ou *${prefixo}rm_adv /2* )
  
  *_FUNÇÕES EXTRAS_*
  
  Há 3 tipos de sistema automático de advertência:
  
  • (1) - advlink
  • (2) - advlinkgp
  • (3) - advflood
  
  Para saber como cada um funciona, use *${prefixo}info* após o nome do sistema que deseja saber, exemplo: ( *advlink* )
  
By: ${NomeDoBot}`;
}
};

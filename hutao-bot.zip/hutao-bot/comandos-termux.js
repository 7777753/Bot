

1.
termux-setup-storage


2.
pkg upgrade -y && pkg update -y && pkg install nodejs -y && pkg install nodejs-lts -y && pkg install ffmpeg -y && pkg install wget -y && pkg install git -y

3.
cd /sdcard/downloads/hutao-bot

E permite.

*_Após configurado, vamos pra instalação (caso você não tenha o arquivo, instale o mesmo no site do bot: https://blackmd.online/docs ):_*

4.
sh start.sh

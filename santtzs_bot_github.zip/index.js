const { makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
const P = require('pino');
const fs = require('fs');

const PREFIX = '!';
const DONO = '5571991652249';

async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info_baileys');
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
        version,
        auth: state,
        logger: P({ level: 'silent' }),
        printQRInTerminal: false,
        getMessage: async () => ({ conversation: "oi" })
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect, pairingCode } = update;

        if (pairingCode) {
            console.log(`\n[!] CÓDIGO DE PAREAMENTO: ${pairingCode}\nUse no WhatsApp: Dispositivos conectados > Vincular com código numérico`);
        }

        if (connection === 'close') {
            const shouldReconnect = (lastDisconnect?.error)?.output?.statusCode !== DisconnectReason.loggedOut;
            if (shouldReconnect) {
                startBot();
            }
        }

        if (connection === 'open') {
            console.log('[!] BOT CONECTADO COM SUCESSO!');
        }
    });

    sock.ev.on('messages.upsert', async ({ messages }) => {
        const msg = messages[0];
        const from = msg.key.remoteJid;
        const isGroup = from.endsWith('@g.us');
        const body = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';

        if (!body.startsWith(PREFIX)) return;
        const command = body.slice(1).trim().split(/ +/).shift().toLowerCase();

        if (command === 'menu') {
            const menu = `
╭───『 SANTTZS BOT 』───
│ Comandos disponíveis:
│ !menu – Mostrar este menu
│ !rg_aluguel [dias] – Aluguel por dias (grupos)
│ !info – Status do bot
│ !dono – Contato do dono
╰─────────────────────`;
            await sock.sendMessage(from, { text: menu }, { quoted: msg });
        }

        if (command === 'rg_aluguel' && isGroup) {
            const dias = body.split(' ')[1] || '1';
            await sock.sendMessage(from, { text: `Aluguel registrado por ${dias} dia(s)!` }, { quoted: msg });
        }

        if (command === 'info') {
            await sock.sendMessage(from, { text: 'Bot está online e funcional!' }, { quoted: msg });
        }

        if (command === 'dono') {
            await sock.sendMessage(from, { text: `Contato do dono: wa.me/${DONO}` }, { quoted: msg });
        }
    });
}

startBot();